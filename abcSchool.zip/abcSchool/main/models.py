from django.db import models

# Create your models here.
class Students(models.Model):
    name = models.CharField(max_length=255)
    class_in = models.BigIntegerField()
    phone = models.BigIntegerField()
    gr = models.BigIntegerField()
    email = models.CharField(max_length=500)
    grade = models.CharField(max_length=5,null=True)
    password = models.CharField(max_length=255)
    
    def __str__(self):
        return self.name


class Courses(models.Model):
    group = models.CharField(max_length=255)
    start_date = models.DateField()
    description = models.CharField(max_length=1000)

    def __str__(self):
        return self.group



class Staff(models.Model):
    name = models.CharField(max_length=255)
    department = models.CharField(max_length=255)
    email = models.CharField(max_length=500)
    def __str__(self):
        return self.name
    


class Messages(models.Model):
    name = models.CharField(max_length=255)
    email = models.CharField(max_length=500)
    message = models.CharField(max_length=2000)
    phone = models.IntegerField()
    def __str__(self):
        return self.message
    