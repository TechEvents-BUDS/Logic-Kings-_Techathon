from random import Random
from django.shortcuts import redirect, render
from django.template import loader
from django.views.decorators.csrf import csrf_exempt
from django.http import HttpResponse
from django.core.mail import send_mail

from main import models


# Create your views here.

def Home(request):
    template = loader.get_template("index.html")
    return HttpResponse(template.render())

def Students(request):
    stud = models.Students.objects.all().values()
    context = {
        'students' : stud,
    }
    template = loader.get_template("students.html")
    return HttpResponse(template.render(context,request))


def Register(request):
    template = loader.get_template("Register.html")
    return HttpResponse(template.render({'abc':123},request))

def Courses(request):
    courses = models.Courses.objects.all().values()
    context = {
        "courses":courses,
    }

    template = loader.get_template("courses.html")
    return HttpResponse(template.render(context,request))



def send_message(request):
    if request.method == "POST":
        name = request.POST.get("name")
        email = request.POST.get("email")
        phone = request.POST.get("phone")
        message = request.POST.get("message")
        m = models.Messages(name = name, phone =phone , email = email , message = message)
        m.save()
    else:
        template = loader.get_template("contact.html")
        return HttpResponse(template.render({"abc":"bhhff"},request))



def Contact(request):
    template = loader.get_template("contact.html")
    return HttpResponse(template.render())

def Staff(request):
    staff = models.Staff.objects.all().values()
    context = {
        "staff":staff,
    }
    template = loader.get_template("staff.html")
    return HttpResponse(template.render(context,request))

def Registration(request):
     template = loader.get_template("index.html")
     rand = Random()
     gr_no = rand.randint(1000,10000)
     if request.method == 'POST':
        namee = request.POST.get('name')
        emaile = request.POST.get('email')
        class_i = request.POST.get('class')
        passwrd = request.POST.get("password")
        grad = request.POST.get("grade")
        phonee = rand.randint(9200,92999)
        s = models.Students(name=namee,class_in =class_i , phone=phonee, gr=gr_no, email=emaile,grade = grad,password = passwrd)
        s.save()
        send_mail(
        "Confirmation Email",
        "This mail is to inform you that your Registration is Complete",
        'umerhussain17june@gmail.com',
        [emaile],
        fail_silently=False,
        )
        return redirect("/")
     else:
        return HttpResponse(template.render())
     
def Testing(request):

    return redirect("/")


def Assistant(request):
    template = loader.get_template("assistant.html")
    return HttpResponse(template.render())

def Login(request):
    template =loader.get_template("login.html")
    return HttpResponse(template.render())


@csrf_exempt
def Login_method(request):
    if request.method == "POST":
        GR = request.POST.get("gr")
        password = request.POST.get("pass")
        s = models.Students.objects.get(gr=GR)
        template = loader.get_template("index.html")
        if(s.password == password):
            return HttpResponse(template.render({"abc":"bhhff"},request))
        else:
            return HttpResponse("Invalid Gr or Password")

